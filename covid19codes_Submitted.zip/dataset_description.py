# -*- coding: utf-8 -*-
import warnings
warnings.filterwarnings('ignore')
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os

os.chdir('D:\\Minhaz\\covid19codes')

#Apple Mobility - 13th January - 2nd June
am_dataset = pd.read_csv('Mobility/applemobilitytrends.csv', sep=',')

braz_data = am_dataset[am_dataset['region']=='Brazil']
braz_mobility = braz_data.drop(['geo_type', 'region', 'alternative_name', 'sub-region', 'country', 'transportation_type'], axis=1)

mobility = braz_mobility.mean(axis=0).to_frame()
mobility.columns = ['brazil_mobility']
mobility['brazil_mobility'].interpolate(method='linear', inplace=True)
mobility['brazil_trend'] = mobility.iloc[:,0].rolling(window=7).mean()

fig, ax = plt.subplots(nrows=1, ncols=1, figsize=[15,5])
ax.plot(mobility['brazil_mobility'].to_numpy(), label="Mobility-Brazil")
ax.plot(mobility['brazil_trend'].to_numpy(), label='Trend')
plt.title("Day wise mobility of Brazil (13th Jan - 2nd June)")
plt.axvline(x=60, label=mobility.index[60], c='black')
handles, labels = ax.get_legend_handles_labels()
lgd = ax.legend(handles, labels, loc=2, bbox_to_anchor=(1, 1))

#Covid Infection data - 22nd January - 1st June
cv_dataset = pd.read_csv('time_series_covid_19_confirmed.csv', sep=',')

cv_Italy = cv_dataset[cv_dataset['Country/Region']=='Italy']
cv_Italy = cv_Italy.drop(['Province/State', 'Country/Region', 'Lat', 'Long'], axis=1)
cv_Italy = cv_Italy.transpose()
print(cv_Italy)
cv_Italy.columns = ['Confirmed Cases']

#Normalizing for plot
cv_It_cumul = cv_Italy['Confirmed Cases'].to_numpy()
cv_It_chang = cv_It_cumul[1:] - cv_It_cumul[:-1]
cv_It_chang = np.insert(cv_It_chang, 0, cv_It_chang[0])
cv_It_cumul = cv_It_cumul / max(cv_It_cumul)
cv_It_chang = cv_It_chang / max(cv_It_chang)


fig, ax = plt.subplots(nrows=1, ncols=1, figsize=[15,5])
ax.plot(cv_It_cumul, label="Cumulative Confirmed Cases", c='blue')
ax.plot(cv_It_chang, label="New Cases on the Day", c='green')
plt.title("COVID-19 infection spread data - Italy (22nd Jan - 1st June)")
plt.axvline(x=9, label="January 31 - First Reported Case", c='black')
plt.axvline(x=59, label="March 11 - Infection Peaked", c='red')
handles, labels = ax.get_legend_handles_labels()
lgd = ax.legend(handles, labels, loc=2, bbox_to_anchor=(1, 1))


#Trend Analysis of four countries India, Italy, Belgium, Bangladesh

cv_Italy = cv_dataset[cv_dataset['Country/Region']=='Italy']
cv_Italy = cv_Italy.drop(['Province/State', 'Country/Region', 'Lat', 'Long'], axis=1)
cv_Italy = cv_Italy.transpose()
cv_Italy.columns = ['Confirmed Cases']
#Normalizing for plot
cv_It_cumul = cv_Italy['Confirmed Cases'].to_numpy()
cv_It_chang = cv_It_cumul[1:] - cv_It_cumul[:-1]
cv_It_chang = cv_It_chang / max(cv_It_chang)

cv_Italy = cv_dataset[cv_dataset['Country/Region']=='India']
cv_Italy = cv_Italy.drop(['Province/State', 'Country/Region', 'Lat', 'Long'], axis=1)
cv_Italy = cv_Italy.transpose()
cv_Italy.columns = ['Confirmed Cases']
#Normalizing for plot
cv_In_cumul = cv_Italy['Confirmed Cases'].to_numpy()
cv_In_chang = cv_In_cumul[1:] - cv_In_cumul[:-1]
cv_In_chang = cv_In_chang / max(cv_In_chang)

cv_Italy = cv_dataset[cv_dataset['Country/Region']=='Belgium']
cv_Italy = cv_Italy.drop(['Province/State', 'Country/Region', 'Lat', 'Long'], axis=1)
cv_Italy = cv_Italy.transpose()
cv_Italy.columns = ['Confirmed Cases']
#Normalizing for plot
cv_B_cumul = cv_Italy['Confirmed Cases'].to_numpy()
cv_B_chang = cv_B_cumul[1:] - cv_B_cumul[:-1]
cv_B_chang = cv_B_chang / max(cv_B_chang)

cv_Italy = cv_dataset[cv_dataset['Country/Region']=='Bangladesh']
cv_Italy = cv_Italy.drop(['Province/State', 'Country/Region', 'Lat', 'Long'], axis=1)
cv_Italy = cv_Italy.transpose()
cv_Italy.columns = ['Confirmed Cases']
#Normalizing for plot
cv_Bd_cumul = cv_Italy['Confirmed Cases'].to_numpy()
cv_Bd_chang = cv_Bd_cumul[1:] - cv_Bd_cumul[:-1]
cv_Bd_chang = cv_Bd_chang / max(cv_Bd_chang)


fig, ax = plt.subplots(nrows=1, ncols=1, figsize=[15,10])
ax.plot(cv_It_chang, label="Change - Italy", c='Blue')
ax.plot(cv_In_chang, label="Change - India", c='Black')
ax.plot(cv_B_chang, label="Change - Belgium", c='Red')
ax.plot(cv_Bd_chang, label="Change - Bangladesh", c='Green')
plt.title("COVID-19 Change Data (22nd Jan - 1st June)")
handles, labels = ax.get_legend_handles_labels()
lgd = ax.legend(handles, labels, loc=2, bbox_to_anchor=(1, 1))











