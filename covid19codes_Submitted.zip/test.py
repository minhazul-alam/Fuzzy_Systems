# -*- coding: utf-8 -*-
import warnings
warnings.filterwarnings('ignore')
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os

from pyFTS.common import Util
from pyFTS.benchmarks import Measures
from pyFTS.partitioners import Grid, Entropy
from pyFTS.models import hofts, pwfts
from pyFTS.common import Membership

os.chdir('D:\\Minhaz\\covid19codes')

#Apple Mobility - 13th January - 2nd June
am_dataset = pd.read_csv('Mobility/applemobilitytrends.csv', sep=',')

braz_data = am_dataset[am_dataset['region']=='Brazil']
braz_mobility = braz_data.drop(['geo_type', 'region', 'alternative_name', 'sub-region', 'country', 'transportation_type'], axis=1)

mobility = braz_mobility.mean(axis=0).to_frame()
mobility.columns = ['brazil_mobility']
mobility['brazil_mobility'].interpolate(method='linear', inplace=True)
mobility['brazil_trend'] = mobility.iloc[:,0].rolling(window=7).mean()

fig, ax = plt.subplots(nrows=1, ncols=1, figsize=[15,5])
ax.plot(mobility['brazil_mobility'].to_numpy(), label="Mobility-Brazil")
ax.plot(mobility['brazil_trend'].to_numpy(), label='Trend')
plt.title("Day wise mobility of Brazil (13th Jan - 2nd June)")
plt.axvline(x=60, label=mobility.index[60], c='black')
handles, labels = ax.get_legend_handles_labels()
lgd = ax.legend(handles, labels, loc=2, bbox_to_anchor=(1, 1))

#Covid Infection data - 22nd January - 1st June
cv_dataset = pd.read_csv('time_series_covid_19_confirmed.csv', sep=',')

cv_Brazil = cv_dataset[cv_dataset['Country/Region']=='Italy']
cv_Brazil = cv_Brazil.drop(['Province/State', 'Country/Region', 'Lat', 'Long'], axis=1)
cv_Brazil = cv_Brazil.transpose()
cv_Brazil.columns = ['Confirmed Cases']

#Normalizing for plot
cv_It_cumul = cv_Brazil['Confirmed Cases'].to_numpy()
cv_It_chang = cv_It_cumul[1:] - cv_It_cumul[:-1]
cv_It_chang = np.insert(cv_It_chang, 0, cv_It_chang[0])
cv_It_cumul = cv_It_cumul / max(cv_It_cumul)
cv_It_chang = cv_It_chang / max(cv_It_chang)


fig, ax = plt.subplots(nrows=1, ncols=1, figsize=[15,5])
ax.plot(cv_It_cumul, label="Cumulative Confirmed Cases")
ax.plot(cv_It_chang, label="New Cases on the Day")
plt.title("COVID-19 infection spread data - Italy (22nd Jan - 1st June)")
plt.axvline(x=59, label=cv_Brazil.index[59], c='black')
handles, labels = ax.get_legend_handles_labels()
lgd = ax.legend(handles, labels, loc=2, bbox_to_anchor=(1, 1))


cv_Brazil_change = cv_Brazil['Confirmed Cases'].to_numpy()
cv_Brazil_change = cv_Brazil_change[1:] - cv_Brazil_change[:-1]
fig, ax = plt.subplots(nrows=1, ncols=1, figsize=[15,5])
ax.plot(cv_Brazil_change, label="Corona Trend")
handles, labels = ax.get_legend_handles_labels()
lgd = ax.legend(handles, labels, loc=2, bbox_to_anchor=(1, 1))



#normalizing
cv_Brazil /= max(cv_Brazil)
cv_Brazil_change /= max(cv_Brazil_change)

# hypothesizing corrrelation upto 7 days ---
# 23 - 7 = 16th January braz_mobility[3:] 
# 26 Apr + 7 = 3rd May cv_Brazil_change[:-6]

#16th Jan - 3rd May - 102 days
fig, ax = plt.subplots(nrows=1, ncols=1, figsize=[15,5])
ax.plot(braz_mobility[3:], label="Mobility Trend")
ax.plot(cv_Brazil_change[:-6], label="Corona Trend")
handles, labels = ax.get_legend_handles_labels()
lgd = ax.legend(handles, labels, loc=2, bbox_to_anchor=(1, 1))

#Pearson Correlation (-1 -- +1)
corr = np.corrcoef(braz_mobility[73:], cv_Brazil_change[70:-6].astype('float64'))
print(corr)

corr = np.corrcoef(braz_driving, braz_walking)

y = dataset.to_numpy()[0]

rows = []

fig, ax = plt.subplots(nrows=1, ncols=1,figsize=[15,7])
ax.plot(y, label="Original Data", color="Black")

part = Grid.GridPartitioner(data=y, npart=80)

model = hofts.HighOrderFTS(order=2, partitioner=part)
model.fit(y)
forecasts = model.predict(y)
plt_fc = np.insert(forecasts, 0, y[0])
ax.plot(plt_fc, label="HOFTS")
rmse, mape, u = Measures.get_point_statistics(y, model)
rows.append(["HOFTS", rmse, mape, u])

model = hofts.WeightedHighOrderFTS(order=2, partitioner=part)
model.fit(y)
forecasts = model.predict(y)
plt_fc = np.insert(forecasts, 0, y[0])
ax.plot(plt_fc, label="WHOFTS")
rmse, mape, u = Measures.get_point_statistics(y, model)
rows.append(["WHOFTS", rmse, mape, u])

model = pwfts.ProbabilisticWeightedFTS(order=2, partitioner=part)
model.fit(y)
forecasts = model.predict(y)
plt_fc = np.insert(forecasts, 0, y[0])
ax.plot(plt_fc, label="PWFTS")
rmse, mape, u = Measures.get_point_statistics(y, model)
rows.append(["PWFTS", rmse, mape, u])

handles, labels = ax.get_legend_handles_labels()
lgd = ax.legend(handles, labels, loc=2, bbox_to_anchor=(1, 1))

df = pd.DataFrame(rows, columns=['Algorithms','RMSE','MAPE','U'])
print(df)














