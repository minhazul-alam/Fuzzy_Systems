# -*- coding: utf-8 -*-
import warnings
warnings.filterwarnings('ignore')
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os

os.chdir('D:\\Minhaz\\covid19codes')

#Apple Mobility - 13th January - 2nd June
am_dataset = pd.read_csv('Mobility/applemobilitytrends.csv', sep=',')

braz_data = am_dataset[am_dataset['region']=='Brazil']
braz_mobility = braz_data.drop(['geo_type', 'region', 'alternative_name', 'sub-region', 'country', 'transportation_type'], axis=1)

mobility = braz_mobility.mean(axis=0).to_frame()
mobility.columns = ['brazil_mobility']
mobility['brazil_mobility'].interpolate(method='linear', inplace=True)
braz_mob = mobility['brazil_mobility'].to_numpy()
#mobility['brazil_trend'] = mobility.iloc[:,0].rolling(window=7).mean()

#Covid Infection data - 22nd January - 1st June
cv_dataset = pd.read_csv('time_series_covid_19_confirmed.csv', sep=',')
cv_Brazil = cv_dataset[cv_dataset['Country/Region']=='Brazil'] ###
cv_Brazil = cv_Brazil.drop(['Province/State', 'Country/Region', 'Lat', 'Long'], axis=1)
cv_Brazil = cv_Brazil.transpose()
cv_Brazil.columns = ['Confirmed Cases']
cv_Br_cumul = cv_Brazil['Confirmed Cases'].to_numpy()
cv_Br_chang = cv_Br_cumul[1:] - cv_Br_cumul[:-1]

cv_Br_chang = np.insert(cv_Br_chang, 0, cv_Br_chang[0])

# hypothesizing corrrelation upto 2 to 8 days ---
# Mobility 20 Jan - C19 22 Jan - 2 days
# Mobility 30 May - C19 1 Jun
corr_coeff = []
for lag in range(2, 9):
    corr = np.corrcoef(braz_mob[(8 - lag):(-1 - lag)], cv_Br_cumul[:].astype('float64'))
    corr_coeff.append(corr[0][1])
print(corr_coeff)

#Normalize the data
braz_mob = braz_mob/max(braz_mob)
cv_Br_cumul = cv_Br_cumul/max(cv_Br_cumul)
cv_Br_chang = cv_Br_chang/max(cv_Br_chang)

fig, ax = plt.subplots(nrows=1, ncols=1, figsize=[12,6])
ax.plot(braz_mob[:-9], label="Change in Mobility")
ax.plot(cv_Br_chang[:], label="COVID-19 Infection Rate")
handles, labels = ax.get_legend_handles_labels()
lgd = ax.legend(handles, labels, loc=2, bbox_to_anchor=(1, 1))

















