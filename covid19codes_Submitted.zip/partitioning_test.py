# -*- coding: utf-8 -*-
import warnings
warnings.filterwarnings('ignore')
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os

from pyFTS.common import Util
from pyFTS.benchmarks import Measures
from pyFTS.partitioners import Grid, Util as pUtil
from pyFTS.models import hofts
from pyFTS.common import Membership as mf

os.chdir('D:\\Minhaz\\covid19codes')
#Covid Infection data - 22nd January - 1st June
cv_dataset = pd.read_csv('time_series_covid_19_confirmed.csv', sep=',')

cv_Brazil = cv_dataset[cv_dataset['Country/Region']=='Brazil']
cv_Brazil = cv_Brazil.drop(['Province/State', 'Country/Region', 'Lat', 'Long'], axis=1)

cv_India = cv_dataset[cv_dataset['Country/Region']=='India']
cv_India = cv_India.drop(['Province/State', 'Country/Region', 'Lat', 'Long'], axis=1)

cv_Italy = cv_dataset[cv_dataset['Country/Region']=='Italy']
cv_Italy = cv_Italy.drop(['Province/State', 'Country/Region', 'Lat', 'Long'], axis=1)

# generating day-by-day data from cumulative data and normalizing
braz = cv_Brazil.to_numpy()[0]
braz = braz[1:] - braz[:-1]
braz = braz/max(braz)

india = cv_India.to_numpy()[0]
india = india[1:] - india[:-1]
india = india/max(india)

italy = cv_Italy.to_numpy()[0]
italy = italy[1:] - italy[:-1]
italy = italy/max(italy)

br_rows = []
in_rows = []
it_rows = []

partitioning = [20, 25, 30, 35, 40, 45, 50, 55]

for npart in partitioning:
    part = Grid.GridPartitioner(data=india, npart=npart)
    model = hofts.HighOrderFTS(order=5, partitioner=part)
    model.fit(india)
    forecasts = model.predict(india)
    plt_fc = np.insert(forecasts, 0, india[0])
    rmse, mape, u = Measures.get_point_statistics(india, model)
    in_rows.append(rmse)

for npart in [20, 25, 30, 35, 40, 45, 50, 55]:
    part = Grid.GridPartitioner(data=braz, npart=npart)
    model = hofts.HighOrderFTS(order=5, partitioner=part)
    model.fit(braz)
    forecasts = model.predict(braz)
    plt_fc = np.insert(forecasts, 0, braz[0])
    rmse, mape, u = Measures.get_point_statistics(braz, model)
    br_rows.append(rmse)

for npart in [20, 25, 30, 35, 40, 45, 50, 55]:
    part = Grid.GridPartitioner(data=italy, npart=npart)
    model = hofts.HighOrderFTS(order=5, partitioner=part)
    model.fit(italy)
    forecasts = model.predict(italy)
    plt_fc = np.insert(forecasts, 0, italy[0])
    rmse, mape, u = Measures.get_point_statistics(italy, model)
    it_rows.append(rmse)

fig, ax = plt.subplots(nrows=1, ncols=1,figsize=[12,6])
plt.xticks([0, 1, 2, 3, 4, 5, 6, 7],partitioning)
plt.grid(axis='y', linestyle='-')
ax.plot(br_rows, label='RMSE - Brazil', c='blue')
ax.plot(in_rows, label='RMSE - India', c='green')
ax.plot(it_rows, label='RMSE - Italy', c='black')
ax.set_title("Effect of Number of Partition on RMSE")
ax.set_ylabel("RMSE value")
ax.set_xlabel("No. of Partition")
handles, labels = ax.get_legend_handles_labels()
lgd = ax.legend(handles, labels, loc=2, bbox_to_anchor=(1, 1))

part = pUtil.explore_partitioners(data=braz, npart=35, methods=[Grid.GridPartitioner], 
                                  mf=[mf.trimf, mf.trapmf, mf.gaussmf])

#checking different membership functions
it_rows = []
part = Grid.GridPartitioner(data=italy, npart=35, mf=[mf.trimf])
model = hofts.HighOrderFTS(order=5, partitioner=part)
model.fit(italy)
forecasts = model.predict(italy)
plt_fc = np.insert(forecasts, 0, italy[0])
rmse, mape, u = Measures.get_point_statistics(italy, model)
it_rows.append(rmse)

part = Grid.GridPartitioner(data=italy, npart=35, mf=[mf.trapmf])
model = hofts.HighOrderFTS(order=5, partitioner=part)
model.fit(italy)
forecasts = model.predict(italy)
plt_fc = np.insert(forecasts, 0, italy[0])
rmse, mape, u = Measures.get_point_statistics(italy, model)
it_rows.append(rmse)

part = Grid.GridPartitioner(data=italy, npart=35, mf=[mf.gaussmf])
model = hofts.HighOrderFTS(order=5, partitioner=part)
model.fit(italy)
forecasts = model.predict(italy)
plt_fc = np.insert(forecasts, 0, italy[0])
rmse, mape, u = Measures.get_point_statistics(italy, model)
it_rows.append(rmse)















