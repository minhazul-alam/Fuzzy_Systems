# -*- coding: utf-8 -*-
import warnings
warnings.filterwarnings('ignore')
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
from statsmodels.tsa.stattools import acf

os.chdir('D:\\Minhaz\\covid19codes')


#Covid Infection data - 22nd January - 1st June
cv_dataset = pd.read_csv('time_series_covid_19_confirmed.csv', sep=',')

cv_Brazil = cv_dataset[cv_dataset['Country/Region']=='Brazil']
cv_Brazil = cv_Brazil.drop(['Province/State', 'Country/Region', 'Lat', 'Long'], axis=1)

cv_India = cv_dataset[cv_dataset['Country/Region']=='India']
cv_India = cv_India.drop(['Province/State', 'Country/Region', 'Lat', 'Long'], axis=1)

cv_Italy = cv_dataset[cv_dataset['Country/Region']=='Italy']
cv_Italy = cv_Italy.drop(['Province/State', 'Country/Region', 'Lat', 'Long'], axis=1)

# generating day-by-day data from cumulative data
braz = cv_Brazil.to_numpy()[0]
braz = braz[1:] - braz[:-1]
india = cv_India.to_numpy()[0]
india = india[1:] - india[:-1]
italy = cv_Italy.to_numpy()[0]
italy = italy[1:] - italy[:-1]

fig, ax = plt.subplots(nrows=1, ncols=1,figsize=[12,6])
ax.plot(acf(braz,nlags=14), label='ACF of Brazilian infection data', c='blue')
ax.plot(acf(india,nlags=14), label='ACF of Indian infection data', c='green')
ax.plot(acf(italy,nlags=14), label='ACF of Italian infection data', c='black')
ax.set_title("Autocorrelation (Lag) Estimation")
ax.set_ylabel("ACF value")
ax.set_xlabel("LAG")
handles, labels = ax.get_legend_handles_labels()
lgd = ax.legend(handles, labels, loc=2, bbox_to_anchor=(1, 1))

